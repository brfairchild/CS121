package classActivity;

public class oneClass {

    // Instant Variables
    int age;
    String major;
    boolean hasJobCurrently;

    // Default constructor
    oneClass(){
        this.age = 0;
        this.major="null";
        this.hasJobCurrently=false;
    }

    // Setting constructor
    oneClass(int age, String major, boolean hasJobCurrently){
        this.age = age;
        this.major = major;
        this.hasJobCurrently = hasJobCurrently;
    }

    // Setters and Getters

}
