package classActivity;

public class testClass {
    public static void main(String[] args) {
        //Creating instance of oneClass
        oneClass kevin = new oneClass(19,"Computer Science", true);
        oneClass bill = new oneClass(21,"English",false);

        System.out.println("Kevin is a " + kevin.major+" and he is "+ kevin.age+" years old.");
        System.out.println("Bill is a " + bill.major+ " and he is "+bill.age+" years old.");
        System.out.println("It is " + kevin.hasJobCurrently + " that Kevin currently has a job.");
        System.out.println("It is " + bill.hasJobCurrently + " that Bill currently has a job.");

        //Creating instance of twoClass
        twoClass sarah = new twoClass(3.9,true,"English");
        twoClass ryan = new twoClass(2.1,false,"Physics");
        System.out.println("\nSarah has a GPA of "+sarah.gpa+" and it is "+sarah.passClass +" that she is passing "+sarah.className);
        System.out.println("Ryan has a GPA of "+ryan.gpa+" and it is "+ryan.passClass + " that he is passing "+ ryan.className);
    }
}
