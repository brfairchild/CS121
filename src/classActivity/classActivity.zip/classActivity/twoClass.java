package classActivity;

public class twoClass {
    double gpa;
    boolean passClass;
    String className;


    twoClass(){
        this.gpa=0;
        this.passClass=false;
        this.className=null;
    }
    twoClass(double gpa, boolean passClass,String className){
        this.gpa=gpa;
        this.passClass = passClass;
        this.className=className;
    }
}
