package weekSix;

import org.junit.Test;

import static org.junit.Assert.*;

public class testTest {
    //Create an instance of your class
    car Tesla = new car("Tesla","S",2022,20000);


    @Test
    public void main() {
        // assertEquals();
        // assertNotNull();
        // assertTrue(); AND assertFalse();
    }
    void testConstructor(){
        // One way to test a constructor
        // car Honda = new car();
        // assertNotNull(Honda);
    }

    void isElectricCar(){
        // this can be used specifically to see if a boolean returns true.
    }


}